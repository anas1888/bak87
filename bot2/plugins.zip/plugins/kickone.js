import { eliteNumbers } from '../elite.js'; 

export default {
    name: 'امر طرد الكل', 
    command: ['تعذيب'],
    category: 'زرف',  
    description: 'يطرد جميع الأعضاء شخصًا شخصًا.', 
    args: [],  
    hidden: false, 
    execution: async ({ sock, m, args, prefix, sleep }) => {
      if (!m.key.remoteJid.endsWith('@g.us')) {
        return sock.sendMessage(m.key.remoteJid, { text: 'هذا الأمر يعمل فقط داخل المجموعات.' });
      }
      const senderNumber = m.key.participant; 
      console.log("الرقم المرسل: ", senderNumber); 
      
      if (!eliteNumbers.includes(senderNumber)) {
        return sock.sendMessage(m.key.remoteJid, { text: 'دز ما عندك صلاحية.' });
      }

      try {
        const groupMetadata = await sock.groupMetadata(m.key.remoteJid);
        const participants = groupMetadata.participants;
        const admins = participants.filter(participant => participant.admin);
        const adminIds = admins.map(admin => admin.id);
        const toRemove = participants.filter(participant => 
          participant.id !== senderNumber &&  
          !adminIds.includes(participant.id) &&  
          !eliteNumbers.includes(participant.id) 
        );

        if (toRemove.length > 0) {
          for (let i = 0; i < toRemove.length; i++) {
            const participant = toRemove[i];
            await sock.groupParticipantsUpdate(m.key.remoteJid, [participant.id], 'remove');
            await sleep(100); // تأخير 100 مللي ثانية بين كل طرد وآخر
          }
        } else {
          sock.sendMessage(m.key.remoteJid, { text: 'ما في أعضاء للطرد.' });
        }
      } catch (error) {
        console.error('فشل في طرد الأعضاء:', error);
        sock.sendMessage(m.key.remoteJid, { text: 'راجع نفسك.' });
      }
    },
};