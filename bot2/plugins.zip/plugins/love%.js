export default {
  name: 'نسبة الحب',
  command: ['حب3'],
  category: 'إدارة',
  description: 'يحدد نسبة الحب لشخص معين في المجموعة أو لشخص عشوائي.',
  args: ['@user'],
  execution: async ({ sock, m, args, prefix, sleep }) => {
    if (!m.key.remoteJid.endsWith('@g.us')) {
      return sock.sendMessage(m.key.remoteJid, { text: '❌ هذا الأمر يعمل فقط داخل المجموعات.' });
    }

    let who;

    // التحقق من وجود منشن أو رد على رسالة أو استخدام args
    if (m.isGroup) {
      if (m.mentionedJid && m.mentionedJid.length > 0) {
        // إذا كان هناك منشن
        who = m.mentionedJid[0];
      } else if (m.quoted) {
        // إذا كان هناك رد على رسالة
        who = m.quoted.sender;
      } else if (args[0]) {
        // إذا تم إدخال الرقم يدوياً
        who = args[0];
      }
    } else {
      who = m.chat;
    }

    // إذا لم يتم تحديد شخص باستخدام منشن أو رد على رسالة أو إدخال الرقم
    if (!who) {
      // إذا لم يتم تحديد الشخص، اختيار عشوائي من الأعضاء في المجموعة
      const groupMembers = await sock.groupMetadata(m.key.remoteJid).then(metadata => metadata.participants);
      const randomMember = groupMembers[Math.floor(Math.random() * groupMembers.length)].id;
      who = randomMember;
      sock.sendMessage(m.key.remoteJid, { text: `لم يتم تحديد شخص. تم اختيار شخص عشوائي من المجموعة.` });
    }

    // توليد نسبة حب عشوائية من 0 إلى 100
    const lovePercentage = Math.floor(Math.random() * 101);

    // إرسال الرسالة التي توضح نسبة الحب
    await sock.sendMessage(
      m.key.remoteJid, 
      { text: `نسبة الحب لـ *@${who.split('@')[0]}* هي: ${lovePercentage}% 💖` }
    );
  },
};