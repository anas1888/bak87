export default {
  name: 'أمر كت',
  command: ['كت'],
  category: 'عمل',
  description: 'إرسال رسائل عشوائية عندما يتم إرسال كلمة "كت"',
  args: [],
  execution: async ({ sock, m, args, prefix, sleep }) => {
    // التأكد من وجود global.db.data.chats
    if (!global.db || !global.db.data || !global.db.data.chats) {
      return sock.sendMessage(m.key.remoteJid, { text: 'حدث خطأ في قاعدة البيانات.' });
    }

    let chat = global.db.data.chats[m.chat];
    let responses;

    // التحقق من أن الرسالة تحتوي على كلمة "كت"
    if (/^كت$/i.test(m.text)) {
      responses = [
        `*∞──────「كـت」──────∞*\n*~『لوفي』~*\n*∞──────「كـت」──────∞*`, 
        `*∞──────「كـت」──────∞*\n*~『ناروتو』~*\n*∞──────「كـت」──────∞*`, 
        `*∞──────「كـت」──────∞*\n*~『سابو』~*\n*∞──────「كـت」──────∞*`, 
        `*∞──────「كـت」──────∞*\n*~『ايس』~*\n*∞──────「كـت」──────∞*`, 
        `*∞──────「كـت」──────∞*\n*~『رايلي』~*\n*∞──────「كـت」──────∞*`, 
        `*∞──────「كـت」──────∞*\n*~『جيرايا』~*\n*∞──────「كـت」──────∞*`, 
        `*∞──────「كـت」──────∞*\n*~『ايتاتشي』~*\n*∞──────「كـت」──────∞*`, 
        `*∞──────「كـت」──────∞*\n*~『ساسكي』~*\n*∞──────「كـت」──────∞*`
        // أضف باقي الردود هنا كما في الكود الأصلي
      ];
    }

    if (responses) {
      let randomIndex = Math.floor(Math.random() * responses.length);
      sock.sendMessage(m.key.remoteJid, { text: responses[randomIndex] });
    }
  },
  hidden: false,
};