import fs from 'fs';
import { eliteNumbers } from '../elite.js'; // استيراد النخبة من الملف الخارجي

export default {
  name: 'نظام التحذيرات مع الأمنشن',
  command: ['انذار'],
  category: 'إدارة',
  description: 'نظام تحذيرات مع إمكانية ذكر الشخص عند التحذير وإزالته بعد 3 تحذيرات (فقط لأعضاء النخبة)',
  execution: async ({ sock, m, args }) => {
    const groupId = m.key.remoteJid;
    if (!groupId.endsWith('@g.us')) return;

    const warningsFile = './warnings.json';
    let warningsData = {};

    // تحميل بيانات التحذيرات
    if (fs.existsSync(warningsFile)) {
      warningsData = JSON.parse(fs.readFileSync(warningsFile, 'utf8'));
    }

    // التأكد من أن المرسل موجود في البيانات
    const sender = m.key.participant;
    warningsData[groupId] = warningsData[groupId] || {};

    // **التحقق من أن المرسل هو عضو نخبة**
    if (!eliteNumbers.includes(sender)) {
      return await sock.sendMessage(groupId, { text: '❌ هذا الأمر مخصص فقط لأعضاء النخبة.' });
    }

    // جلب الأمر المستخدم
    const mentionedUser = m.message.extendedTextMessage?.contextInfo?.mentionedJid?.[0];

    if (!mentionedUser) {
      return await sock.sendMessage(groupId, { text: 'منشن الشخص يا اهبل.' });
    }

    warningsData[groupId][mentionedUser] = warningsData[groupId][mentionedUser] || 0;

    // زيادة عدد التحذيرات للشخص الممنشن
    warningsData[groupId][mentionedUser] += 1;

    // حفظ بيانات التحذيرات
    fs.writeFileSync(warningsFile, JSON.stringify(warningsData));

    const warningsCount = warningsData[groupId][mentionedUser];

    // إرسال تحذير
    await sock.sendMessage(groupId, {
      text: `
       تم تحذير العضو ${mentionedUser.split('@')[0]}. التحذيرات الحالية: ${warningsCount}`
    });

    // إذا وصل الشخص إلى 3 تحذيرات، يتم إزالته
    if (warningsCount >= 3) {
      await sock.sendMessage(groupId, {
        text: `❗ تم إزالة العضو ${mentionedUser.split('@')[0]} بسبب تكرار التحذيرات.`
      });

      // استخدام groupParticipantsUpdate لإزالة العضو
      try {
        await sock.groupParticipantsUpdate(groupId, [mentionedUser], 'remove');
        // إعادة تعيين التحذيرات بعد الإزالة
        warningsData[groupId][mentionedUser] = 0;
        fs.writeFileSync(warningsFile, JSON.stringify(warningsData));
      } catch (error) {
        console.error('حدث خطأ أثناء محاولة إزالة العضو:', error);
        await sock.sendMessage(groupId, { text: '❌ حدث خطأ أثناء محاولة إزالة العضو.' });
      }
    }
  },
};