export default {
  name: 'أمر الاختبار', 
  command: ['تست'], 
  category: 'عمل',
  description: 'أمر لاختبار البوت', 
  args: [], 
  execution: ({ sock, m, args, prefix, sleep }) => {
    sock.sendMessage(m.key.remoteJid, { text: 'ساكاموتو' });
  },
  hidden: false,
};
