export default {
  name: 'سبام رسائل',
  command: ['سبام'],
  category: 'إدارة',
  description: 'إرسال عدد معين من الرسائل إلى جهة اتصال',
  args: ['نص الرسالة', 'عدد الرسائل'],
  execution: async ({ sock, m, args }) => {
    // التحقق من وجود النص وعدد الرسائل
    if (args.length < 2) {
      await sock.sendMessage(m.key.remoteJid, {
        text: '❗ استخدم الأمر بهذه الصيغة: سبام <النص> <عدد الرسائل>',
      });
      return;
    }

    const messageText = args.slice(0, -1).join(' ');
    const messageCount = parseInt(args[args.length - 1], 10);

    if (isNaN(messageCount) || messageCount <= 0) {
      await sock.sendMessage(m.key.remoteJid, {
        text: '❗ يجب إدخال عدد صحيح للرسائل.',
      });
      return;
    }

    for (let i = 0; i < messageCount; i++) {
      await sock.sendMessage(m.key.remoteJid, { text: messageText });
    }

    await sock.sendMessage(m.key.remoteJid, {
      text: `✅ تم إرسال ${messageCount} رسالة بنجاح.`,
    });
  },
  hidden: false,
};