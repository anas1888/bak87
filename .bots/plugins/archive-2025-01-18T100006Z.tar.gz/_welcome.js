import { WAMessageStubType } from '@whiskeysockets/baileys';
import fetch from 'node-fetch';

export async function before(m, { conn, participants, groupMetadata }) {
  if (!m.messageStubType || !m.isGroup) return !0;
  
  let pp = await conn.profilePictureUrl(m.messageStubParameters[0], 'image').catch(_ => 'https://files.catbox.moe/8e5q0e.jpg');
  let img = await (await fetch(`${pp}`)).buffer();
  let chat = global.db.data.chats[m.chat];
  
  let who = m.messageStubParameters[0] + '@s.whatsapp.net';
  let user = global.db.data.users[who];
  
  let userName = user ? user.name : await conn.getName(who);

  if (chat.welcome && m.messageStubType == 27) {
    let bienvenida = `⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯
> ┊❄️┊⇇ مــنــور/ه يا ｢@${m.messageStubParameters[0].split`@`[0]}｣
*⧈─╼━╾╼━┇•❄️•┇━╾─╼╾─⧈*
*┊❄️┊المنشن⇇｢@${m.messageStubParameters[0].split`@`[0]}｣*
*┊❄️┊الـمـجــمـو؏ــــه⇇｢${groupMetadata.subject}｣*
*⧈─╼━╾╼━┇•❄️•┇━╾─╼╾─⧈*
> مـــلـــحوظات مـــهــمــــه⤺

*┊𝟙┊⇇｢استخدم امر(.قوانين) حتي تعرف قوانين المجموعه｣*
*┊𝟚┊⇇｢استخدم(.اوامر)لي عرض اوامر البوت｣*
*┊𝟛┊⇇｢ممنوع دخول للبوت خاص ｣*
*⧈─╼━╾╼━┇•❄️•┇━╾─╼╾─⧈*
*┊❄️┊البوت:•⪼𝐀𝐁𝐘𝐒𝐒*
*┊❄️┊⇦تـوقـيــــ؏⇇𝑅𝐴𝐷𝐼𝑂 𝐷𝐸𝑀𝑂𝑁* 
⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯`;

    await conn.sendAi(m.chat, packname, dev, bienvenida, img, img, canal, estilo);
  }

  if (chat.welcome && m.messageStubType == 28) {
    let bye = `⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯
> ┊❄️┊⇇لقــــــد غــادر ｢@${m.messageStubParameters[0].split`@`[0]}｣
*⧈─╼━╾╼━┇•❄️•┇━╾─╼╾─⧈*
*┊❄️┊المنشن⇇｢@${m.messageStubParameters[0].split`@`[0]}｣*
*┊❄️┊الـمـجــمـو؏ــــه⇇｢${groupMetadata.subject}｣*
*⧈─╼━╾╼━┇•❄️•┇━╾─╼╾─⧈*
*┊❄️┊البوت:•⪼𝐀𝐁𝐘𝐒𝐒*
*┊❄️┊⇦تـوقـيــــ؏⇇𝑅𝐴𝐷𝐼𝑂 𝐷𝐸𝑀𝑂𝑁* 
⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯`;

    await conn.sendAi(m.chat, packname, dev, bye, img, img, canal, estilo);
  }

  if (chat.welcome && m.messageStubType == 32) {
    let kick = `⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯
> ┊❄️┊⇇لقــــــد غــادر ｢@${m.messageStubParameters[0].split`@`[0]}｣
*⧈─╼━╾╼━┇•❄️•┇━╾─╼╾─⧈*
┊❄️┊المنشن⇇｢@${m.messageStubParameters[0].split`@`[0]}｣
┊❄️┊الـمـجــمـو؏ــــه⇇｢${groupMetadata.subject}｣
*⧈─╼━╾╼━┇•❄️•┇━╾─╼╾─⧈*
*┊❄️┊البوت:•⪼𝐀𝐁𝐘𝐒𝐒*
*┊❄️┊⇦تـوقـيــــ؏⇇𝑅𝐴𝐷𝐼𝑂 𝐷𝐸𝑀𝑂𝑁* 
⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯`;

    await conn.sendAi(m.chat, packname, dev, kick, img, img, canal, estilo);
  }
}