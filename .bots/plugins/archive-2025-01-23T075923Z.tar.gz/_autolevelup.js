import { canLevelUp, xpRange } from '../lib/levelling.js';
import { levelup } from '../lib/canvas.js';
import fetch from 'node-fetch';
import canvafy from 'canvafy';

let handler = (m) => m;
handler.before = async function (m, { conn }) {
  if (!db.data.chats[m.chat].autolevelup) return;

  let who = m.mentionedJid && m.mentionedJid[0]
    ? m.mentionedJid[0]
    : m.fromMe
    ? conn.user.jid
    : m.sender;

  let pp = await conn
    .profilePictureUrl(who, 'image')
    .catch((_) => 'https://telegra.ph/file/24fa902ead26340f3df2c.png');

  let name = await conn.getName(m.sender);
  let user = global.db.data.users[m.sender];
  let chat = global.db.data.chats[m.chat];
  if (!chat.autolevelup) return true;

  let level = user.level;
  let before = user.level * 1;

  while (canLevelUp(user.level, user.exp, global.multiplier)) user.level++;
  if (before !== user.level) {
    const roles = global.roles;
    let role = Object.keys(roles).reduce((acc, key) => {
      if (roles[key] <= user.level) acc = key;
      return acc;
    }, '🌱 كون I');

    let text = `✨ *¡تهانينا ${name}!*\n\n` +
      `🎯 *مستوى جديد:*\n` +
      `- *لفل القديم*: ${before}\n` +
      `- *لفلك*: ${user.level}\n` +
      `- مستواك: ${role}`;

    const levelUpImage = await new canvafy.LevelUp()
      .setAvatar(pp)
      .setBackground("image", "https://qu.ax/pZVUy.jpg")
      .setUsername(name)
      .setBorder("#000000")
      .setAvatarBorder("#ff0000")
      .setOverlayOpacity(0.7)
      .setLevels(before, user.level)
      .build();

    await conn.sendFile(
      m.chat,
      levelUpImage,
      `levelup-${m.sender}.png`,
      `*\`乂 *لفل*  -  *جديد* 乂\`*\n\n` +
      `*┌  ◦ \`لاسم:\`* ${name}\n` +
      `*├  ◦ \`المستوى:\`* ${role}\n` +
      `*├  ◦ \`لاكسبي:\`* ${user.exp} xp\n` +
      `*└  ◦ \`لفل:\`* [ ${before} ] ➠ [ ${user.level} ]\n\n© -❀ᩙ̈͟༚̮ ⡞᪲=͟͟͞s᪶۫۫a᪶۫۫s᪶۫۫u᪶۫۫k᪶۫i᪶۫ b᪶۫o᪶۫t᪶۫۫͜ ≼᳞ׄ ᵎ ˚꙳꤬ꨪ`.trim(),
      m, null, fake
    );
  }
};
export default handler;

global.roles = {
  '🌱 *كون* I': 0,
  '🌱 *كون* II': 2,
  '🌱 *كون* III': 4,
  '🌱 *كون* IV': 6,
  '🌱 *كون* V': 8,
  '🛠️ *اوريهيمه اينوي* I': 10,
  '🛠️ *اوريهيمه اينوي* II': 12,
  '🛠️ *اوريهيمه اينوي* III': 14,
  '🛠️ *اوريهيمه اينوي* IV': 16,
  '🛠️ *اوريهيمه اينوي* V': 18,
  '⚔️ *يامي ريالغو* I': 20,
  '⚔️ *يامي ريالغو* II': 22,
  '⚔️ *يامي ريالغو* III': 24,
  '⚔️ *يامي ريالغو* IV': 26,
  '⚔️ *يامي ريالغو* V': 28,
  '🏹 *اولكويورا سيفرو* I': 30,
  '🏹 *اولكويورا سيفرو* II': 32,
  '🏹 *اولكويورا سيفرو* III': 34,
  '🏹 *اولكويورا سيفرو* IV': 36,
  '🏹 *اولكويورا سيفرو* V': 38,
  '🛡️ *رينجي اباراي* I': 40,
  '🛡️ *رينجي اباراي* II': 42,
  '🛡️ *رينجي اباراي* III': 44,
  '🛡️ *رينجي اباراي* IV': 46,
  '🛡️ *رينجي اباراي* V': 48,
  '🔮 *كينباتشي زاراكي* I': 50,
  '🔮 *كينباتشي زاراكي* II': 52,
  '🔮 *كينباتشي زاراكي* III': 54,
  '🔮 *كينباتشي زاراكي* IV': 56,
  '🔮 *كينباتشي زاراكي* V': 58,
  '🏅 *اتشيغو كوروساكي* I': 60,
  '🏅 *اتشيغو كوروساكي* II': 62,
  '🏅 *اتشيغو كوروساكي* III': 64,
  '🏅 *اتشيغو كوروساكي* IV': 66,
  '🏅 *اتشيغو كوروساكي* V': 68,
  '💎 *ايزن سوسكي* I': 70,
  '💎 *ايزن سوسكي* II': 72,
  '💎 *ايزن سوسكي* III': 74,
  '💎 *ايزن سوسكي* IV': 76,
  '💎 *ايزن سوسكي* V': 78,
  '🌌 *يوهاباخ* I': 80,
  '🌌 *يوهاباخ* II': 85,
  '🌌 *يوهاباخ* III': 90,
  '🌌 *يوهاباخ* IV': 95,
  '🌌 *يوهاباخ* V': 99,
  '🌀 *ساسكي* I': 100,
  '🌀 *ساسكي* II': 110,
  '🌀 *ساسكي* III': 120,
  '🌀 *ساسكي* IV': 130,
  '🌀 *ساسكي* V': 140,
  '👑 *غريمجو جيران* I': 150,
  '👑 *غريمجو جيران* II': 160,
  '👑 *غريمجو جيران* III': 170,
  '👑 *غريمجو جيران* IV': 180,
  '👑 *غريمجو جيران* V': 199,
  '🚀 بطل I': 200,
  '🚀 بطل II': 225,
  '🚀 بطل III': 250,
  '🚀 Campeón IV': 275,
  '🚀 Campeón V': 299,
  '✨ Luz I': 300,
  '✨ Luz II': 325,
  '✨ Luz III': 350,
  '✨ Luz IV': 375,
  '✨ Luz V': 399,
  '🪐 Tejedor I': 400,
  '🪐 Tejedor II': 425,
  '🪐 Tejedor III': 450,
  '🪐 Tejedor IV': 475,
  '🪐 Tejedor V': 499,
  '🪞 Reflejo I': 500,
  '🪞 Reflejo II': 525,
  '🪞 Reflejo III': 550,
  '🪞 Reflejo IV': 575,
  '🪞 Reflejo V': 599,
  '🦋 Meta I': 600,
  '🦋 Meta II': 625,
  '🦋 Meta III': 650,
  '🦋 Meta IV': 675,
  '🦋 Meta V': 699,
  '💠 Runas I': 700,
  '💠 Runas II': 725,
  '💠 Runas III': 750,
  '💠 Runas IV': 775,
  '💠 Runas V': 799,
  '🧠 Mente I': 800,
  '🧠 Mente II': 825,
  '🧠 Mente III': 850,
  '🧠 Mente IV': 875,
  '🧠 Mente V': 899,
  '🛸 Viajero I': 900,
  '🛸 Viajero II': 925,
  '🛸 Viajero III': 950,
  '🛸 Viajero IV': 975,
  '🛸 Viajero V': 999,
  '🔥 Héroe I': 1000,
  '🔥 Héroe II': 2000,
  '🔥 Héroe III': 3000,
  '🔥 Héroe IV': 4000,
  '🔥 Héroe V': 5000,
  '👑🌌 Deidad': 10000,
};
