let WAMessageStubType = (await import('@whiskeysockets/baileys')).default;

export async function before(m, { conn, participants, groupMetadata }) {
  if (!m.messageStubType || !m.isGroup) return;

  const fkontak = {
    key: {
      participants: "0@s.whatsapp.net",
      remoteJid: "status@broadcast",
      fromMe: false,
      id: "Halo",
    },
    message: {
      contactMessage: {
        vcard: `BEGIN:VCARD\nVERSION:3.0\nN:Sy;Bot;;;\nFN:y\nitem1.TEL;waid=${m.sender.split('@')[0]}:${m.sender.split('@')[0]}\nitem1.X-ABLabel:Ponsel\nEND:VCARD`,
      },
    },
    participant: "0@s.whatsapp.net",
  };

  let usuario = `@${m.sender.split`@`[0]}`;
  let pp = await conn.profilePictureUrl(m.chat, 'image').catch(_ => null) || 'https://qu.ax/QGAVS.jpg';

  let nombre, foto, edit, newlink, status, admingp, noadmingp;

  // تغيير اسم المجموعة
  nombre = `*⧈─╼━╾╼━┇•❄️•┇━╾─╼╾─⧈*
*┇❄️┇ ⇇ تم تغيير اسم المجموعة بواسطة ➥* 
*┇❄️┇ عضو ⇇ ${usuario}*
*┇❄️┇ الاسم الجديد ⇇ ${m.messageStubParameters[0]}*
*⧈─╼━╾╼━┇•❄️•┇━╾─╼╾─⧈*`;

  // تغيير صورة المجموعة
  foto = `*⧈─╼━╾╼━┇•❄️•┇━╾─╼╾─⧈*
*┇❄️┇ ⇇ تم تغيير صورة المجموعة بواسطة ➥* 
*┇❄️┇ عضو ⇇ ${usuario}*
*⧈─╼━╾╼━┇•❄️•┇━╾─╼╾─⧈*`;

  // التعديل على إعدادات المجموعة
  edit = `*⧈─╼━╾╼━┇•❄️•┇━╾─╼╾─⧈*
*┇❄️┇ ⇇ تم تعديل إعدادات المجموعة بواسطة ➥* 
*┇❄️┇ عضو ⇇ ${usuario}*
*┇❄️┇ التعديل*: ${m.messageStubParameters[0] == 'on' ? 'لأدمن فقط' : 'للجميع'}
*⧈─╼━╾╼━┇•❄️•┇━╾─╼╾─⧈*`;

  // تغيير رابط المجموعة
  newlink = `*⧈─╼━╾╼━┇•❄️•┇━╾─╼╾─⧈*
*┇❄️┇ ⇇ تم تغيير رابط المجموعة بواسطة ➥* 
*┇❄️┇ عضو ⇇ ${usuario}*
*⧈─╼━╾╼━┇•❄️•┇━╾─╼╾─⧈*`;

  // الحالة (مفتوح أو مغلق)
  status = `*⧈─╼━╾╼━┇•❄️•┇━╾─╼╾─⧈*
*┇❄️┇ ⇇ تم تغيير حالة المجموعة بواسطة ➥* 
*┇❄️┇ عضو ⇇ ${usuario}*
*┇❄️┇ الحالة ⇇ ${m.messageStubParameters[0] == 'on' ? 'مغلق 🔒' : 'مفتوح 🔓'}*
*⧈─╼━╾╼━┇•❄️•┇━╾─╼╾─⧈*`;

  // الترقيه
  admingp = `*⧈─╼━╾╼━┇•❄️•┇━╾─╼╾─⧈*
*┇❄️┇ ⇇ تم ترقيتك إلى مشرف بواسطة ➥* 
*┇❄️┇ عضو ⇇ ${usuario}*
*┇❄️┇ الترقيه بواسطة ⇇ ${m.messageStubParameters[0] == 'on' ? 'مدير المجموعة' : 'شخص آخر'}*
*⧈─╼━╾╼━┇•❄️•┇━╾─╼╾─⧈*`;

  // الإعفاء
  noadmingp = `*⧈─╼━╾╼━┇•❄️•┇━╾─╼╾─⧈*
*┇❄️┇ ⇇ تم إعفائك من المشرف بواسطة ➥* 
*┇❄️┇ عضو ⇇ ${usuario}*
*┇❄️┇ الإعفاء بواسطة ⇇ ${m.messageStubParameters[0] == 'on' ? 'مدير المجموعة' : 'شخص آخر'}*
*⧈─╼━╾╼━┇•❄️•┇━╾─╼╾─⧈*`;

  // إرسال الرسائل
  if (chat.detect && m.messageStubType == 21) {
    await conn.sendMessage(m.chat, { text: nombre, mentions: [m.sender] }, { quoted: fkontak });
  } else if (chat.detect && m.messageStubType == 22) {
    await conn.sendMessage(m.chat, { image: { url: pp }, caption: foto, mentions: [m.sender] }, { quoted: fkontak });
  } else if (chat.detect && m.messageStubType == 23) {
    await conn.sendMessage(m.chat, { text: newlink, mentions: [m.sender] }, { quoted: fkontak });
  } else if (chat.detect && m.messageStubType == 25) {
    await conn.sendMessage(m.chat, { text: edit, mentions: [m.sender] }, { quoted: fkontak });
  } else if (chat.detect && m.messageStubType == 26) {
    await conn.sendMessage(m.chat, { text: status, mentions: [m.sender] }, { quoted: fkontak });
  } else if (chat.detect && m.messageStubType == 29) {
    // منشن وهمي للمشرفين
    let adminMentions = participants.filter(p => p.admin).map(p => p.id);
    await conn.sendMessage(m.chat, { text: admingp, mentions: [m.sender, ...adminMentions] }, { quoted: fkontak });
  } else if (chat.detect && m.messageStubType == 30) {
    // منشن وهمي للمشرفين
    let adminMentions = participants.filter(p => p.admin).map(p => p.id);
    await conn.sendMessage(m.chat, { text: noadmingp, mentions: [m.sender, ...adminMentions] }, { quoted: fkontak });
  } else {
    //console.log({ messageStubType: m.messageStubType, messageStubParameters: m.messageStubParameters, type: WAMessageStubType[m.messageStubType] });
  }
}