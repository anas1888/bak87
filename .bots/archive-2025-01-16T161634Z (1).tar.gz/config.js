import { watchFile, unwatchFile } from 'fs' 
import chalk from 'chalk'
import { fileURLToPath } from 'url'
import fs from 'fs'
import cheerio from 'cheerio'
import fetch from 'node-fetch'
import axios from 'axios'
import moment from 'moment-timezone' 

//*─ׄ─ׅ─ׄ─⭒─ׄ─ׅ─ׄ─⭒─ׄ─ׅ─ׄ─⭒─ׄ─ׅ─ׄ─⭒─ׄ─ׅ─ׄ─⭒─ׄ─ׅ─ׄ─*

//BETA: Si quiere evitar escribir el número que será bot en la consola, agregué desde aquí entonces:
global.botNumberCode = '' //Ejemplo: +573218138672
global.confirmCode = ''

//*─ׄ─ׅ─ׄ─⭒─ׄ─ׅ─ׄ─⭒─ׄ─ׅ─ׄ─⭒─ׄ─ׅ─ׄ─⭒─ׄ─ׅ─ׄ─⭒─ׄ─ׅ─ׄ─*

global.owner = [
   ['201063808608', '*𝑅𝐴𝐷𝐼𝑂 𝐷𝐸𝑀𝑂𝑁*', true],
   ['201063808608', '*𝑅𝐴𝐷𝐼𝑂 𝐷𝐸𝑀𝑂𝑁*', true],
   ['201063808608', '𝑅𝐴𝐷𝐼𝑂 𝐷𝐸𝑀𝑂𝑁', true],
   ['201063808608', '*𝑅𝐴𝐷𝐼𝑂 𝐷𝐸𝑀𝑂𝑁*', true],
   ['201063808608'],
   ['201063808608'],
   ['201063808608']
]

//*─ׄ─ׅ─ׄ─⭒─ׄ─ׅ─ׄ─⭒─ׄ─ׅ─ׄ─⭒─ׄ─ׅ─ׄ─⭒─ׄ─ׅ─ׄ─⭒─ׄ─ׅ─ׄ─*

global.mods = []
global.prems = []

//*─ׄ─ׅ─ׄ─⭒─ׄ─ׅ─ׄ─⭒─ׄ─ׅ─ׄ─⭒─ׄ─ׅ─ׄ─⭒─ׄ─ׅ─ׄ─⭒─ׄ─ׅ─ׄ─*

//cambiar a true si el bot detecta sus propios comandos.
global.isBaileysFail = false
global.libreria = 'Baileys'
global.baileys = 'V 6.7.5'
global.vs = '2.0.7'
global.vsJB = '5.0'
global.nameqr = '𝐀𝐁𝐘𝐒𝐒_𝐁𝐎𝐓'
global.namebot ='𝐀𝐁𝐘𝐒𝐒_𝐁𝐎𝐓'
global.sessions = 'ABYSS-Session'
global.jadi = 'ABYS-BOT'

//*─ׄ─ׅ─ׄ─⭒─ׄ─ׅ─ׄ─⭒─ׄ─ׅ─ׄ─⭒─ׄ─ׅ─ׄ─⭒─ׄ─ׅ─ׄ─⭒─ׄ─ׅ─ׄ─*

global.packname = '𝐀𝐁𝐘𝐒𝐒_𝐁𝐎𝐓'
global.botname = '*𝐀𝐁𝐘𝐒𝐒_𝐁𝐎𝐓*'
global.wm = '𝐀𝐁𝐘𝐒𝐒_𝐁𝐎𝐓'
global.author = '*_┇❄️┇بواسطه شيطان الاذاعه_*'
global.dev = '*_┇❄️┇بواسطه شيطان الاذاعه_*'
global.textbot = '*_┇❄️┇بواسطه شيطان الاذاعه_*'
global.namebot = '𝐀𝐁𝐘𝐒𝐒_𝐁𝐎𝐓'
global.stickpack = '©𝐀𝐁𝐘𝐒𝐒_𝐁𝐎𝐓'
global.titulowm = '𝐀𝐁𝐘𝐒𝐒_𝐁𝐎𝐓'
global.titulowm2 = '𝐀𝐁𝐘𝐒𝐒_𝐁𝐎𝐓'
global.igfg = '@ism_edit0'
global.titu = '*_┇❄️┇بواسطه شيطان الاذاعه_*'
global.listo = '*_┇✅┇⇇تم الانتهاء من طلبك_'
global.vs = '2.0.7'
global.namechannel = '╎𝑷𝑨𝑵𝑫𝑶𝑹𝑨〘🧭〙𝑪𝑶𝑴𝑷𝑨𝑵𝒀╎'
global.stickauth = `©𝐀𝐁𝐘𝐒𝐒_𝐁𝐎𝐓`
global.dis = ':⁖֟⊱┈֟፝❥'

//*─ׄ─ׅ─ׄ─⭒─ׄ─ׅ─ׄ─⭒─ׄ─ׅ─ׄ─⭒─ׄ─ׅ─ׄ─⭒─ׄ─ׅ─ׄ─⭒─ׄ─ׅ─ׄ─*

global.catalogo = fs.readFileSync('./src/catalogo.png')

//*─ׄ─ׅ─ׄ─⭒─ׄ─ׅ─ׄ─⭒─ׄ─ׅ─ׄ─⭒─ׄ─ׅ─ׄ─⭒─ׄ─ׅ─ׄ─⭒─ׄ─ׅ─ׄ─*

global.group = 'https://chat.whatsapp.com/GUc8ghn8q4I1VjjeDWb2hV'
global.group2 = 'https://chat.whatsapp.com/ERhz9ZL51nb3K8tSBawJnQ'
global.canal = 'https://whatsapp.com/channel/0029VaumDtWJZg4B8jLyMK2q'
global.github = 'https://github.com/Angelito-OFC/Genesis-AI' 
global.instagram = 'https://www.instagram.com/ism_edit0' 
global.whatsApp = 'https://wa.me/201032238860'

//*─ׄ─ׅ─ׄ─⭒─ׄ─ׅ─ׄ─⭒─ׄ─ׅ─ׄ─⭒─ׄ─ׅ─ׄ─⭒─ׄ─ׅ─ׄ─⭒─ׄ─ׅ─ׄ─*

global.estilo = { key: {  fromMe: false, participant: `0@s.whatsapp.net`, ...(false ? { remoteJid: "5219992095479-1625305606@g.us" } : {}) }, message: { orderMessage: { itemCount : -999999, status: 1, surface : 1, message: 'ᰔᩚ *_𝐀𝐁𝐘𝐒𝐒_𝐁𝐎𝐓_*', orderTitle: 'Bang', thumbnail: catalogo, sellerJid: '0@s.whatsapp.net'}}};
global.fakegif2 = { key: { participant: `0@s.whatsapp.net`, ...(false ? { remoteJid: "5219992095479-1625305606@g.us" } : {}) }, message: { videoMessage: { title: 's᪶۫۫a᪶۫۫s᪶۫۫u᪶۫۫k᪶۫i᪶۫ b᪶۫o᪶۫t۫۫', h: `Hmm`, seconds: '99999', gifPlayback: true, caption: '⚘݄𖠵⃕⁖𖥔*_منور_*❞ ꔷ──᜔◇⃟̣̣⃕✨', jpegThumbnail: catalogo }}};

global.fakegif3 = { key: { participant: `0@s.whatsapp.net`, ...(false ? { remoteJid: "5219992095479-1625305606@g.us" } : {}) }, message: { videoMessage: { title: '𝐀𝐁𝐘𝐒𝐒_𝐁𝐎𝐓', h: `Hmm`, seconds: '99999', gifPlayback: true, caption: '⚘݄𖠵⃕⁖s a s u k ɪ ♡', jpegThumbnail: catalogo }}};

global.fakegif4 = { key: { participant: `0@s.whatsapp.net`, ...(false ? { remoteJid: "5219992095479-1625305606@g.us" } : {}) }, message: { videoMessage: { title: '𝐀𝐁𝐘𝐒𝐒_𝐁𝐎𝐓', h: `Hmm`, seconds: '99999', gifPlayback: true, caption: '⚘݄𖠵⃕⁖*_استيكر_* (^_^♪) 🤍', jpegThumbnail: catalogo }}};

//*─ׄ─ׅ─ׄ─⭒─ׄ─ׅ─ׄ─⭒─ׄ─ׅ─ׄ─⭒─ׄ─ׅ─ׄ─⭒─ׄ─ׅ─ׄ─⭒─ׄ─ׅ─ׄ─*

global.ch = {
ch1: '120363376982425324@newsletter',
ch2: '120363376982425324@newsletter'
}

//*─ׄ─ׅ─ׄ─⭒─ׄ─ׅ─ׄ─⭒─ׄ─ׅ─ׄ─⭒─ׄ─ׅ─ׄ─⭒─ׄ─ׅ─ׄ─⭒─ׄ─ׅ─ׄ─*

global.APIs = { // API Prefix
  // name: 'https://website' 
  nrtm: 'https://fg-nrtm.ddns.net',
  fgmods: 'https://api.fgmods.xyz'
}
global.APIKeys = { // APIKey Here
  // 'https://website': 'apikey'
  'https://api.fgmods.xyz': 'm2XBbNvz' //-- 100 de límite diario --- Regístrese en https://api.fgmods.xyz/
}

//*─ׄ─ׅ─ׄ─⭒─ׄ─ׅ─ׄ─⭒─ׄ─ׅ─ׄ─⭒─ׄ─ׅ─ׄ─⭒─ׄ─ׅ─ׄ─⭒─ׄ─ׅ─ׄ─*

global.cheerio = cheerio
global.fs = fs
global.fetch = fetch
global.axios = axios
global.moment = moment        

//*─ׄ─ׅ─ׄ─⭒─ׄ─ׅ─ׄ─⭒─ׄ─ׅ─ׄ─⭒─ׄ─ׅ─ׄ─⭒─ׄ─ׅ─ׄ─⭒─ׄ─ׅ─ׄ─*

global.multiplier = 69
global.maxwarn = '3'

//*─ׄ─ׅ─ׄ─⭒─ׄ─ׅ─ׄ─⭒─ׄ─ׅ─ׄ─⭒─ׄ─ׅ─ׄ─⭒─ׄ─ׅ─ׄ─⭒─ׄ─ׅ─ׄ─*

let file = fileURLToPath(import.meta.url)
watchFile(file, () => {
  unwatchFile(file)
  console.log(chalk.redBright("Update 'settings.js'"))
  import(`${file}?update=${Date.now()}`)
})
