## 【 **`G E N E S I S - AI`** 】
<a href="https://git.io/typing-svg"><img src="https://readme-typing-svg.demolab.com?font=Oswald&weight=300&size=37&duration=3000&pause=100&color=000000&background=601D6E00&center=true&vCenter=true&repeat=true&random=FALSO&width=660&height=90&lines=Angel-OFC+lanzó+la mejor+versión;De+Genesis Ultra - 2.0.0;Con+nuevos+comandos+y+mejoras;Genesis-Ultra+El+Mejor Bot+De+WhatsApp" alt="Typing SVG"/></a>
![img](https://i.ibb.co/1djcb0T/file.jpg)

[![GROUP OFFICIAL](https://img.shields.io/badge/WhatsApp%20grupo-25D366?style=for-the-badge&logo=whatsapp&logoColor=white)](https://chat.whatsapp.com/GqKwwoV2JJaJDP2SL7SddX) [![GROUP OFFICIAL](https://img.shields.io/badge/WhatsApp%20channel-25D366?style=for-the-badge&logo=whatsapp&logoColor=white)](https://whatsapp.com/channel/0029VaJxgcB0bIdvuOwKTM2Y)

![img](https://i.ibb.co/mhB98TL/file.jpg)


<a href="https://api.whatsapp.com/send/?phone=+59897246324&text=Hola 👋 soporte de Génesis Bot &type=phone_number&app_absent=0" target="blank"><img src="https://img.shields.io/badge/Whatsapp-30302f?style=flat&logo=whatsapp" /></a>
 <a href="http://www.instagram.com/angelito.kzx" target="blank"><img src="https://img.shields.io/badge/Instagram-30302f?style=flat&logo=instagram" /></a>
<a href="https://www.threads.net/@angelito.kzx" target="blank"><img src="https://img.shields.io/badge/Threads-30302f?style=flat&logo=threads" /></a>
<a href="https://x.com/usxr_angelito0" target="blank"><img src="https://img.shields.io/badge/Twitter-30302f?style=flat&logo=x" /></a>

<a href="https://github.com/Izumi-kzx/Genesis-AI/watchers"><img title="espectadores" src="https://img.shields.io/github/watchers/Izumi-kzx/Genesis-AI?label=Espectadores&style=social"></a>
</p>

</p>
<p align="center"><img src="https://profile-counter.glitch.me/{Genesis-AI}/count.svg" alt="Izumi-kzx:: Visitor's Count" /></p>

</p>

### **`❕️Información importante`**

<details>
 <summary><b> 🤍 Nota Importante </b></summary>

Este proyecto **no está afiliado de ninguna manera** con `WhatsApp`, `Inc. WhatsApp` es una marca registrada de `WhatsApp LLC`, y este bot es un **desarrollo independiente** que **no tiene ninguna relación oficial con la companía**.

</details>

<details>
 <summary><b> 🤍 Importante </b></summary>

GenesisBot-MD recibe **soporte semanal** si llegas a ver un error **repetitivamente o presenta fallos** solo repórtelo para que lo solucionemos

</details>

<details>
 <summary><b> 🤍 Versión 2.0.0</b></summary>

* **Este proyecto no ofrece soporte oficial para su uso en Termux.** Termux es una aplicación de terminal para Android y, aunque puede ser utilizada para ejecutar diversos programas, **este proyecto no está diseñado ni probado específicamente para funcionar en Termux**. Por lo tanto, **no garantizamos compatibilidad ni soporte técnico en este entorno**.

</details>

### <img src="https://i.pinimg.com/originals/19/80/6e/19806e91932e6054965fc83b85241270.gif" alt="Prueba La Bot Aqui" width="42" height="42"> **`Instala Genesis Aqui`**

### **`TK HOST 📲`**
<a href="https://dash.tk-joanhost.com"><img src="https://i.ibb.co/pr8TnWJ/SAVE-20240915-183758.jpg" height="125px"></a>

- **Dashboard:** [`Aquí`](https://dash.tk-joanhost.com)
- **Panel:** [`Aquí`](https://panel.tk-joanhost.com)
- **Canal de WhatsApp:** [`Aquí`](https://whatsapp.com/channel/0029VaoZXbk6RGJNYQVP8r27)
- **Texto:** `Genesis Ultra (Bot-Oficial)`
- [x] **Configuración** <details><summary>**Ajustes del Servidor - Genesis-Ultra**</summary><img src="https://i.ibb.co/w6MC5Q4/file.jpg"></details>

### **`🎇 Hosting Py:`**
<a href="https://dahs.hostingpy.shop/"><img src="https://files.catbox.moe/lr92z2.jpg" height="130px"></a>

- **Dashboard:** [`Aquí`](https://dahs.hostingpy.shop/)
- **Panel:** [`Aquí`](https://panel.hostingpy.shop/)
- **Canal de WhatsApp:** [`Aquí`](https://whatsapp.com/channel/0029Vak4e1R4NVifmh8Tvi3q)
- **Contacto:** [`AdrianOficial`](https://wa.me/595976126756)
- **Texto:** `Genesis Ai diponible aqui`


***

> [!IMPORTANT]
> **Si planeas instalar o extraer el bot, recuerda que su venta está estrictamente prohibida bajo cualquier circunstancia. El uso del bot con fines de venta constituye una violación de los términos de nuestro repositorio y se tomarán las medidas necesarias contra quienes incumplan estas condiciones.**

***
### ☁️ COLABORADORES

<a href="https://github.com/MauroAzcurra"><img src="https://github.com/MauroAzcurra.png" width="100" height="100" alt="MauroAzcurra"/></a>

### **`🤍 CREADOR`**
<a
href="https://github.com/Izumi-kzx"><img src="https://github.com/Izumi-kzx.png" width="130" height="130" alt="Angelito"/></a>

> Copyright (c) 2024 **[Angelito-OFC](https://whatsapp.com/channel/0029VaJxgcB0bIdvuOwKTM2Y)**.

**`¡GRACIAS POR PREFERIR ESTE PROYECTO!` ☕**
