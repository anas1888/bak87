import cp, { exec as _exec } from 'child_process';
import { promisify } from 'util';
const exec = promisify(_exec).bind(cp);

const handler = async (m, { conn, isOwner, command, text, usedPrefix, args, isROwner }) => {
  if (!isROwner) return;  // التأكد من أن المستخدم هو المالك الحقيقي
  if (global.conn.user.jid != conn.user.jid) return;  // التأكد من أن البوت نفسه الذي يقوم بتنفيذ الأوامر

  m.reply('💥 *جارٍ تنفيذ الأمر...*');

  let output;
  try {
    output = await exec(command.trimStart() + ' ' + text.trimEnd());
  } catch (e) {
    output = e;
  } finally {
    const { stdout, stderr } = output;
    if (stdout.trim()) m.reply(stdout);  // إرسال الإخراج الناجح
    if (stderr.trim()) m.reply(stderr);  // إرسال أي أخطاء
  }
};

handler.help = ['$'];
handler.tags = ['المالك'];
handler.customPrefix = /^[$] /;
handler.command = new RegExp;

handler.rowner = true;  // التأكد من أن الأمر متاح فقط للمالك الحقيقي

export default handler;