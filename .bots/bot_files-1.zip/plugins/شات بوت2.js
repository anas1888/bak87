let handler = m => m;
handler.all = async function (m) {
  // التحقق مما إذا كانت الرسالة مرسلة من البوت
  if (m.key.fromMe) {
    return; // إيقاف التنفيذ إذا كانت الرسالة مرسلة من البوت
  }

  let chat = global.db.data.chats[m.chat];
  
  if (chat.isBanned) {
    return;  
  }
  
  const wm = '*واتربو*'; // أو يمكنك تعديل هذا لتحديد قيمة `wm` الصحيحة
  
  if (/زفت$/i.test(m.text)) { 
    conn.reply(m.chat, `*زيك*`, m, wm, null, [['الدعم', '#الدعم']]);
  }

  if (/^انت مالك$/i.test(m.text)) { 
    conn.reply(m.chat, `*اغلط فيك اسكت*`, m, wm, null, [['الدعم', '#الدعم']]);
  }
  
  if (/^دز$/i.test(m.text)) { 
    conn.reply(m.chat, `*دز انت🙄*`, m, wm, null, [['الدعم', '#الدعم']]);
  }
 
  if (/^بوت زنجي|اسود|عبد|زنجي$/i.test(m.text)) { 
    conn.reply(m.chat, `*يا عم اسكت و انت شبه الفحمه*`, m, wm, null, [['الدعم', '#الدعم']]);
  }

  if (/^بوسه|هات بوسه$/i.test(m.text)) { 
    conn.reply(m.chat, `*بس يلا🗿*`, m, wm, null, [['الدعم', '#الدعم']]);
  }

  if (/^كلب$/i.test(m.text)) { 
    conn.reply(m.chat, `*شايف نفسك في المرايا*`, m, wm, null, [['الدعم', '#الدعم']]);
  }
  
  if (/^فين$/i.test(m.text)) { 
    conn.reply(m.chat, `*اقولك فين و ما تزعل🌚*`, m, wm, null, [['الدعم', '#الدعم']]);
  }
  
  if (/^شينوبو$/i.test(m.text)) { 
    conn.reply(m.chat, `*بلاش سيرت الكلاب وحشه🙄*`, m, wm, null, [['الدعم', '#الدعم']]);
  }

  if (/^لا$/i.test(m.text)) { 
    conn.reply(m.chat, `*لا ما تلوئك😂*`, m, wm, null, [['الدعم', '#الدعم']]);
  }
  
  if (/^كيرا|العقرب|زورو|ايرين$/i.test(m.text)) { 
    conn.reply(m.chat, `*افضل صحاب مطوري😍*`, m, wm, null, [['الدعم', '#الدعم']]);
  }

  if (/^باندورا هارتس|pandora hearts$/i.test(m.text)) { 
    conn.reply(m.chat, `*افضل انمي والانمي المفضلي لي مطوري😎*`, m, wm, null, [['الدعم', '#الدعم']]);
  }

  if (/^السلام عليكم$/i.test(m.text)) { 
    conn.reply(m.chat, `*وعليكم السلام*`, m, wm, null, [['الدعم', '#الدعم']]);
  }

  if (/^بكرهك$/i.test(m.text)) { 
    conn.reply(m.chat, `*وانا*`, m, wm, null, [['الدعم', '#الدعم']]);
  }
  
  if (/^وات فاك$/i.test(m.text)) { 
    conn.reply(m.chat, `*يا عيني ده انصدم*`, m, wm, null, [['الدعم', '#الدعم']]);
  }

  if (/^ليه$/i.test(m.text)) { 
    conn.reply(m.chat, `*بي جنيه😂*`, m, wm, null, [['الدعم', '#الدعم']]);
  }

  if (/^خخخخخخخخخ|خخخخخ|خخخخخخخخخخخخ$/i.test(m.text)) { 
    conn.reply(m.chat, `*بس بدل ما سحبها ليك اسكندراني😂😂*`, m, wm, null, [['الدعم', '#الدعم']]);
  }

  if (/^انت مالك$/i.test(m.text)) { 
    conn.reply(m.chat, `*وانت مالك انت كمان🤔*`, m, wm, null, [['الدعم', '#الدعم']]);
  }

  if (/^💋$/i.test(m.text)) { 
    conn.reply(m.chat, `*بس يا سافل🐦*`, m, wm, null, [['الدعم', '#الدعم']]);
  }
  
  if (/^آلُـۜسـۨۚ(✋)ــِۖلُأمٌ ؏ـليۜـ(💜)ـكـۜم وݛحـٍّْـٍّْ⁽😘₎ـٍّْمهہ الًـًٍۖـٍـٍۖ(☝)ٍۖـًٍٍٍّـًٍلۖهًٍۖۂ وبـۗـۗـۗـۗـۗـۗركۧۧــۧۧۧۧۧـۗـۗ(ۗ😇)ـۗـۗاتهۂ$/i.test(m.text)) { 
    conn.reply(m.chat, `و؏ٌٍـلًِيٌِگِـٍٍّّـًـًٍ(🌹)ٌٍـٌٍـًٌٍم السـ͜(🤝)ـلاﺂ͘م وݛحـٍّْـٍّْ⁽😘₎ـٍّْمهہ الًـًٍٍۖـٍۖ(☝)ٍۖـًٍٍٍّـًٍلۖهًٍۖۂ وبـۗـۗـۗـۗـۗـۗركۧۧـ(ۗ😇)ـۗـۗاتهۂ`, m, wm, null, [['الدعم', '#الدعم']]);
  }
  
  if (/^راح اطرده|راح اطرد البوت|اطردك$/i.test(m.text)) { 
    conn.reply(m.chat, `*علي الله😒*`, m, wm, null, [['الدعم', '#الدعم']]);
  }
   
  if (/^🌚$/i.test(m.text)) { 
    conn.reply(m.chat, `*مكسوف من ايه😂*`, m, wm, null, [['الدعم', '#الدعم']]);
  }
  
  if (/^جه عمكم$/i.test(m.text)) { 
    conn.reply(m.chat, `*قصدك كلبهم😂*`, m, wm, null, [['الدعم', '#الدعم']]);
  }
   
  if (/^مستفز$/i.test(m.text)) { 
    conn.reply(m.chat, `*وانت خرا☺️*`, m, wm, null, [['الدعم', '#الدعم']]);
  }
  
  return !0;
}
export default handler;