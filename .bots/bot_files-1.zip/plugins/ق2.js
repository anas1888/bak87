let handler = async (m, { conn }) => {
  let user = global.db.data.users[m.sender];
  let name = conn.getName(m.sender) || 'مستخدم';
  let taguser = '@' + m.sender.split("@")[0];

  let currentTime = new Date().toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit' });

  let groupMetadata = m.isGroup ? await conn.groupMetadata(m.chat) : null;
  let groupName = groupMetadata ? groupMetadata.subject : 'غير معروف';
  let groupMembers = groupMetadata ? groupMetadata.participants.length : 'غير معروف';

  let message = `*_:•⪼مـــرحبــــاً بـــكـ/ﻲ يـا ❪${taguser}❫ في قسم الصور_*
*❀✦═══ •『❄️』• ═══✦❀*
> *شرح القسم:•⪼ القسم يحتوي علي صور لي شخصيات الانمي المذكوره❪اي عندما تكتب(.ميكاسا)راح يجيب لك صور لي ميكاسا❫و اوامر تحميل صور و تتطقيمات*
*❆━━━━━⊱⎔⌟❄️⌜⎔⊱━━━━━❆*
> *｢❆┊قــــــســـــــم_الــصـور┊❆｣*
*❆━━━━━⊱⎔⌟❄️⌜⎔⊱━━━━━❆*
┊❄️┊:•⪼⌟هيناتا⌜ 
┊❄️┊:•⪼⌟ميكاسا⌜ 
┊❄️┊:•⪼ ⌟كابلز⌜
┊❄️┊:•⪼ ⌟تطقيم_بنات⌜
┊❄️┊:•⪼⌟ميكو⌜
┊❄️┊:•⪼⌟كورومي⌜
┊❄️┊:•⪼ ⌟كانيكي⌜
┊❄️┊:•⪼ ⌟ساكورا⌜
┊❄️┊:•⪼ ⌟صوره⌜
┊❄️┊:•⪼⌟هيستيا⌜
┊❄️┊:•⪼ ⌟كاوري⌜
*❆━━━━━⊱⎔⌟❄️⌜⎔⊱━━━━━❆*
> ❆ ❯ امر ❪.صوره❫ يحضر لك صوره من النت 
> مثال:•⪼.صوره الاستور يجيب لك صوره المطلوبه اي يجيب صوره الاستور 
> ❆ ❯ من الافضل كتابت الطلب بي الانجليزي و الانمي
*❆━━━━━⊱⎔⌟❄️⌜⎔⊱━━━━━❆*
*┊❄️┊البوت:•⪼𝐀𝐁𝐘𝐒𝐒*
*┊❄️┊⇦تـوقـيــــ؏⇇𝑅𝐴𝐷𝐼𝑂 𝐷𝐸𝑀𝑂𝑁*`;

  const emojiReaction = '📷';

  try {
    await conn.sendMessage(m.chat, { react: { text: emojiReaction, key: m.key } });

    await conn.sendMessage(m.chat, { 
      video: { url: 'https://files.catbox.moe/91yw03.mp4' },
      caption: message,
      gifPlayback: true,
      mentions: [m.sender]
    });
  } catch (error) {
    console.error("Error sending message:", error);
    await conn.sendMessage(m.chat, { text: 'حدث خطأ أثناء إرسال الفيديو.' });
  }
};

handler.command = /^(ق2)$/i;
handler.exp = 50;
handler.fail = null;

export default handler;